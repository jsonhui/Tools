

CommTone Serial port testing / ActiveXForm OCX
------------------------------------------------

Current version: 6.0
Release Date: 2012-01-02
Home: http://www.ceiwei.com
QQ: 348677065
EMAIL: jfyes@qq.com
Download: http://www.ceiwei.com/view.asp?newsid=37

 
CommTone Serial port testing 
----------------------------------------
        CommTone Serial port testing , can improve the development efficiency, eliminating the pain of debugging serial programs. It can set a variety of online communication speed, parity, oral communication without having to restart the program; can set the time to send the data and the time interval; can automatically display the received data, and can string, decimal and hexadecimal free to switch between a system; automatically save the settings parameters, engineering and technical personnel to monitor, debug serial port program an essential tool. Support the common 110-115200bps baud rate, parity can be set, data and stop bits can be in ASCII or hexadecimal receiving or sending any data or characters (including Chinese), can be set automatically send cycle.

       The new version adds send files, send documents to support 4GB size.


      Secondary development interface DEMO
      See detailed method call: Demo \ directory Java7, JavaScript, Delphi, CBuilderXE, VS2008 (C #, VC, VB.net) called DEMO

\ Demo \ ActiveXForm (javascript)
\ Demo \ Delphi7
\ Demo \ C + + BuilderXe2
\ Demo \ VS2008 (C #, VC, VB.net)
\ Demo \ Java7


Operating environment
-------------------------
Windows 2000/XP/2003/Win7

 
 
CommTone Serial port testing 
-------------------------------------------------- ------------------------------
1 serial port is opened, communication parameters can be modified at any time, simply click on the application.

2, enter HEX: user input data as hexadecimal bytes, case insensitive, reception will be displayed as hexadecimal HEX format.

3, enter the ASC: user input data as ASCII characters received will be displayed as ASCII characters.

4 wrap: whether the reception and transmission of data between the wrap show.

5, DTR / RTS: select the corresponding pin goes high after, for some passive 485/422 converter.

6, select the "Enter to send" input area equivalent to pressing the send button, press Enter, if you want to enter multiple lines, use Ctrl + Enter;
  Not selected, the input can enter the area branches.

7, CRC check, the school joined the 16-bit CRC code for each number of bytes sent into the final two.

8, the user input (from the serial output) data is displayed as green, from the serial input data is displayed as blue.

9, the file is sent: Click on [Send File] button, select a file to send, sender and receiver will automatically pop up the other end of the letter
  Information box. Note that when sending files, the number of milliseconds to send periodic intervals, sending the smaller the faster the cycle, if too small can
  The other end can not receive data buffer is full will result in packet loss is like, the proposed cycle value between 20-50 is good.





CommToneX.ocx control
--------------------
 
        CommToneX.ocx to ActivexForm control operation can be embedded in Web pages serial communication,
Functional and CommTone.exe as it CommTone.exe is independent, does not produce dependency.



CommToneX.ocx registration method
---------------------
1 Open Reg.bat register OCX components.

2 with the IE browser to open CommToneX.htm.

3.IE browser will prompt to stop an ActiveX control to determine the run.

4 Open UnReg.bat anti-registration component, delete.



CommToneX.ocx Note
---------------------
1.360 and other security software will block IE browser to load OCX, proposed to close or open the front whitelist.

2 If the ordinary household register OCX control requires administrator privileges.

3.CommToneX.ocx for the trial version.

4 support IE5.0 or above browser.

5 Internet publishing, the client-side Internet Options -> Security -> Internet-> ActiveX items, the appropriate option to enable.




Other
---------------------
CommToneX.ocx to ActiveX Form version of the OCX, you can open the IE browser to load the debug serial port.




License Agreement

-------------------------------------------------- ------------------------------

CEIWEI CommTone end user license agreement Copyright: CEIWEI Network Technology
-------------------------------------------------- -----------------

CEIWEI Network Technology hereinafter referred to as (CEIWEI)

CommTone serial debugging Wizard software, hereinafter referred to as (CommTone)

CEIWEI including root domain CEIWEI.com and all associated sub-domain.

CommTone is CEIWEI provide serial monitoring (surveillance, detection) services for free software.

The "End User License Agreement" (hereinafter referred to as "License Agreement") is a, you (individual or single entity) and "CEIWEI", on

"CommTone" of software products, including written information, related media, media, and may include "CEIWEI.com online" or electronic documentation (the

Hereinafter referred to as "Software Product" or "Software"), the agreement between the legally established. Once you install, copy or otherwise use the "Software Product" means that

Agreed to accept the "License Agreement" terms of the constraints. If you do not agree with this "License Agreement" terms, which may not use the "Software Product."

Copyright belongs to the software product "CEIWEI" and is protected by copyright laws and international copyright conventions and other intellectual property laws and treaties of protection, because

Here, you may not copy the software and accompanying manuals and other written information, and shall not use any method to obtain the use of the software code, text information, plans

Film, video, music and sound effects, and other electronic documents.


1, authorized.
The "Software Product CommTone" only and free to use, the user can not use the release version with the same derivative.

2, limit.
You should keep all "software products CommTone" copy on the copyright notice.

You may not the "software product CommTone" reverse engineering (Reverse engineer), reverse compile (Decompile) or disassemble

(Disassemble). However, if the applicable laws and regulations have prohibited the above limitations, are permitted.

You may not rent, loan or business operation for the purpose of using the "Software Product CommTone".
You must comply with all "software" product of the relevant laws.

3, termination.
If you fail to comply with the "License Agreement" the terms or conditions are "CEIWEI" without prejudice to other powers in the right circumstances, terminate the "License Agreement."

Then you must destroy the "Software Product" all copies.
If you found a part of your online loan or business operation for the purpose of using the "Software Product CommTone", "CEIWEI" the right to terminate use without notice to You

Must, to the court for your proceedings.

4, copyright.
All with the "Software Product" and its copy on the ownership and copyright are "CEIWEI" all of its copyright holder. All through this with the result of "Software Product"

The access to the information content of the ownership and intellectual property are the owner of the information, and is protected by relevant copyright or other intellectual property laws and treaties of protection

Care. The "License Agreement" does not authorize you to enjoy the content of such information to use the power.

5, Disclaimer
Your use of the "Software Product CommTone" and any loss caused by your sole risk. In the relevant maximum extent permitted by law, the "

CEIWEI "and CEIWEI.COM Bug does not assume any responsibility and warranty conditions, whether express or implied, including (but not limited to) merchantability, fitness Hemou

Particular purpose and non-infringement of the rights of others implied warranties.

6, the consequential damages liable.
In the relevant maximum extent permitted by law within, "CEIWEI" or its suppliers for your use of or inability to use the "Software Product" and subject to the special, Yan

Nature, direct or indirect damages (including, without limitation, loss of business interests, business interruption, loss of data or other tangible or intangible losses) assumes no damages

Reward responsibility. This shall not be due to your prior informed "CEIWEI" or its suppliers, the possibility of occurrence of the damage varies.

7, the other provisions.
The "License Agreement" for the Chinese (Hong Kong, Macao and Taiwan) law. On the "License Agreement" for all involved in litigation, you agree to Beijing, China

District Court of first instance court of competent jurisdiction. The "License Agreement" is not mentioned in all the other powers "CEIWEI" are reserved. If you are on the "License Agreement" with

Any questions, please contact "CEIWEI CommTone" author. E-mail: jfyes@hotmail.com

8, other software.
All software products, packaging, instructions and other non-appearance or mention "CEIWEI" the name of all the software and its copyright belongs to the copyright owner of all products,

In their gratitude.

9 Privacy Policy
CEIWEI respect and protect all users use CommTone privacy.


10 to interpret the terms of service and the right to amend part CEIWEI.


-------------------------------------------------- ------------------
Author: jfyes
E-mail: jfyes@qq.com
Website: http://www.ceiwei.com/


-------------------------------------------------- ------------------------------
copyright (C) 2003-2011 CEIWEI Network Technology
www.ceiwei.com
